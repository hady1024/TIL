from random import random
from django.shortcuts import render

# Create your views here.

# View -> 템플릿 파일 지정
def index(request):

    return render(request, "index.html")


def today_beer(request):
    beer_list = [
        {
            "name": "블랑",
            "src": "http://assabeer.com/web/product/big/20200427/19fdcdb504cb5b76b226d7b1f1f674b5.jpg",
        },
        {
            "name": "버드와이저",
            "src": "https://dimg.donga.com/wps/NEWS/IMAGE/2022/07/19/114518398.2.jpg",
        },
        {
            "name": "기네스",
            "src": "https://shop1.daumcdn.net/thumb/R500x500/?fname=http%3A%2F%2Fshop1.daumcdn.net%2Fshophow%2Fp%2FD5107685138.jpg%3Fut%3D20220115214133",
        },
    ]
    beer = random.choice(beer_list)

    context = {"beer": beer}

    return render(request, "today_beer.html", context)
